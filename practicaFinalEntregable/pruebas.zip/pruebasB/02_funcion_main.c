#include <stdio.h>
int x;

main() {
    x = x + 1;
    printf("%d\n", x);
}
//@ (main)
