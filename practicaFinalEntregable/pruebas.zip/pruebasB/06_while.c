#include <stdio.h>
int cnt = 0;

main() {
    while (cnt < 3) {
        printf("%d\n", cnt);
        cnt = cnt + 1;
    }
}
//@ (main)
