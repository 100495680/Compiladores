#include <stdio.h>
int v = 5;
int res;
main() {

    if (v % 2 == 0) {
        puts("Par");
    } else {
        puts("Impar");
    }

    if (v > 10) {
        puts("Grande");
    }
}
//@ (main)
