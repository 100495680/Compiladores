#include <stdio.h>
int a;
int b = 10, c, d = 5;

main() {
    puts("Variables globales");
}

//@ (main)
