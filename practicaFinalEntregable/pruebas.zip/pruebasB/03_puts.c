#include <stdio.h>
int main_var;

main() {
    puts("¡Hola, mundo!");
}
//@ (main)
