#include <stdio.h>
int val = 42;

main() {
    printf("%d", val);
}
//@ (main)
