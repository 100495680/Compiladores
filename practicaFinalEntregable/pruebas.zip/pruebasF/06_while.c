#include <stdio.h>
main() {
    int cnt = 0;
    while (cnt < 3) {
        printf("%d\n", cnt);
        cnt = cnt + 1;
    }
}
//@ (main)
