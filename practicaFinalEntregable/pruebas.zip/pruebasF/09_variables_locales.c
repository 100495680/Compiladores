#include <stdio.h>
main() {
    int g = 1;
    int a = 4, b;
    a = a + 1;
    b = a * 2;
    printf("%d %d\n", a, b);
}
//@ (main)
