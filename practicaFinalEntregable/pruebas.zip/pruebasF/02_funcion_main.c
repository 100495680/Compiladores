#include <stdio.h>
main() {
    int x;
    printf("%d\n", x + 1);
}
//@ (main)
