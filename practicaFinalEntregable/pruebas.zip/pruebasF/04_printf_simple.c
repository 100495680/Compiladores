#include <stdio.h>
main() {
    int val = 42;
    printf("%d", val);
}
//@ (main)
